#include <iostream>
#include "Chicken.h"
using namespace std;





int main(){
    Chicken c;
}