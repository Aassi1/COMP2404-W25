Name : Assi Assi
StudentID : 101302142

Button.cc : Source code for button class that will be used to add Buttons, remove buttons, create buttons and draw the buttons onto the screen.

Button.h : Header file for Button.cc

CuWindow.cc : Source code for CuWindow class that will be used to create the window and draw the panels onto the screen. In turn, these panels will contain the buttons.
There are functions that removePanels, addPanels, and drawPanels.

CuWindow.h : Header file for CuWindow.cc

defs.h : Header file that contains important definitions that will be used throughout the project.

main.cc : Source code for main.cc. This is the main file that will be run and it contains all of the testing code

Makefile : Makefile that will be used to compile the project.

Panel.cc : Source code for Panel class that will be used to create the panels that will be used to contain the buttons.

Panel.h : Header file for Panel.cc

RGB.cc : Source code for RGB class that will be used to create the RGB values for the buttons.

RGB.h : Header file for RGB.cc

Tester.cc : Source code for Tester class that will be used to test the project.

Tester.h : Header file for Tester.cc
